
<?php $__env->startSection('content'); ?>
    <h2>Welcome Login Page</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.beforelogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pa\resources\views/admin/index.blade.php ENDPATH**/ ?>