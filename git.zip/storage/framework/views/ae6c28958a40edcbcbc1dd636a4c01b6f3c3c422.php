<?php $__env->startSection('content'); ?>
    <!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <div class="page-content">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <div class="page-title-box">
                            <h4 class="font-size-18">Add Admin</h4>
                            <ol class="breadcrumb mb-0">
                                <li class="breadcrumb-item"><a href="/">PayAgent</a></li>
                                <li class="breadcrumb-item"><a href="admin_management">Admin Management</a></li>
                                <li class="breadcrumb-item active">Add Admin</li>
                            </ol>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="float-right">
                                <a href="admin_management" class="btn btn-primary waves-effect waves-light">
                                    <i class="mdi mdi-arrow-left mr-2"></i> Back
                                </a>
                        </div>
                    </div>
                </div>
                <!-- end page title -->
                <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <!-- <h4 class="card-title">Example</h4> -->
                                        <form class="repeater" enctype="multipart/form-data">
                                            <div data-repeater-list="group-a">
                                                <div data-repeater-item class="row">
                                                    <div  class="form-group col-lg-3">
                                                        <label for="name">Name</label>
                                                        <input type="text" id="name" name="untyped-input" class="form-control"/>
                                                    </div>

                                                    <div  class="form-group col-lg-3">
                                                        <label for="email">Email</label>
                                                        <input type="email" id="email" class="form-control"/>
                                                    </div>

                                                    <div  class="form-group col-lg-3">
                                                        <label for="subject">Phone</label>
                                                        <input type="text" id="subject" class="form-control"/>
                                                    </div>

                                                    <div class="col-lg-1 align-self-center">

                                                        <input data-repeater-delete type="button" class="btn btn-danger btn-block" value="Delete"/>
                                                    </div>
                                                </div>

                                            </div>
                                            <input data-repeater-create type="button" class="btn btn-success mo-mt-2" value="Add More"/>

                                            <div class="submit_cnt">
                                                <button class="btn btn-primary waves-effect waves-light" type="submit">Submit</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\pa\resources\views/admin/add_admin.blade.php ENDPATH**/ ?>